package chat.guc.edu.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.GroupLayout.Alignment;

import chat.guc.edu.engine.Client;
import chat.guc.edu.engine.Message;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
public class Room extends JPanel implements ActionListener {

	private JTextField ClientIn;
	private JTextArea ChatBox;
	private Client USER;
	private JLabel MSG;
	private String NAME;
	private JMenuItem mntmClose;
	private JMenuItem mntmKickoff;
	private JMenuItem mntmInvite;
	private JMenuItem mntmWho;
	private JMenuItem mntmMute;
	private boolean isMute;
	/**
	 * Create the panel.
	 */
	public Room(Client user, String n) {
		setLayout(null);
		JScrollPane scrollPane = new JScrollPane();
		USER = user;
		ClientIn = new JTextField();
		ClientIn.setColumns(10);
		ClientIn.addActionListener(this);
		
		NAME = n;
		MSG = new JLabel("Enter Message : ");
		GroupLayout gl_panel = new GroupLayout(this);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(ClientIn, GroupLayout.DEFAULT_SIZE, 687, Short.MAX_VALUE)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 687, Short.MAX_VALUE)
						.addComponent(MSG))
					.addContainerGap())
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(54)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 255, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(MSG)
					.addGap(13)
					.addComponent(ClientIn, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(47, Short.MAX_VALUE))
		);
		
		ChatBox = new JTextArea();
		ChatBox.setEditable(false);
		JMenuBar menuBar = new JMenuBar();
		scrollPane.setColumnHeaderView(menuBar);
		
		mntmInvite = new JMenuItem("Invite");
		menuBar.add(mntmInvite);
		mntmInvite.addActionListener(this);
		mntmKickoff = new JMenuItem("KickOff");
		menuBar.add(mntmKickoff);
		mntmKickoff.addActionListener(this);
		mntmClose = new JMenuItem("Close");
		menuBar.add(mntmClose);
		mntmClose.addActionListener(this);
		mntmWho = new JMenuItem("Who");
		mntmWho.addActionListener(this);
		menuBar.add(mntmWho);
		mntmMute = new JMenuItem("Mute");
		mntmMute.addActionListener(this);
		menuBar.add(mntmMute);
		ChatBox.setText("ChatRoom of " + NAME);
		scrollPane.setViewportView(ChatBox);
		this.setLayout(gl_panel);

	}
	
	public Room(Client user) {
		setLayout(null);
		JScrollPane scrollPane = new JScrollPane();
		USER = user;
		ClientIn = new JTextField();
		ClientIn.setColumns(10);
		ClientIn.addActionListener(this);
		
		NAME = user.getNAME();
		MSG = new JLabel("Enter Message : ");
		GroupLayout gl_panel = new GroupLayout(this);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(ClientIn, GroupLayout.DEFAULT_SIZE, 687, Short.MAX_VALUE)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 687, Short.MAX_VALUE)
						.addComponent(MSG))
					.addContainerGap())
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(54)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 255, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(MSG)
					.addGap(13)
					.addComponent(ClientIn, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(47, Short.MAX_VALUE))
		);
		
		ChatBox = new JTextArea();
		ChatBox.setEditable(false);
		JMenuBar menuBar = new JMenuBar();
		scrollPane.setColumnHeaderView(menuBar);
		
		mntmInvite = new JMenuItem("Invite");
		menuBar.add(mntmInvite);
		mntmInvite.addActionListener(this);
		mntmKickoff = new JMenuItem("KickOff");
		menuBar.add(mntmKickoff);
		mntmKickoff.addActionListener(this);
		mntmClose = new JMenuItem("Close");
		menuBar.add(mntmClose);
		mntmClose.addActionListener(this);
		mntmWho = new JMenuItem("Who");
		mntmWho.addActionListener(this);
		menuBar.add(mntmWho);
		mntmMute = new JMenuItem("Mute");
		mntmMute.addActionListener(this);
		menuBar.add(mntmMute);
		ChatBox.setText("ChatRoom");
		scrollPane.setViewportView(ChatBox);
		this.setLayout(gl_panel);

	}
	
	public Room() {
		setLayout(null);
		
		ClientIn = new JTextField();
		ClientIn.setColumns(10);
		
	
		JLabel MSG = new JLabel("Enter Message : ");
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_panel = new GroupLayout(this);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addComponent(scrollPane, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 426, Short.MAX_VALUE)
						.addComponent(ClientIn, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 426, Short.MAX_VALUE)
						.addComponent(MSG, Alignment.LEADING))
					.addContainerGap())
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(72)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 219, GroupLayout.PREFERRED_SIZE)
					.addGap(39)
					.addComponent(MSG)
					.addGap(13)
					.addComponent(ClientIn, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(38, Short.MAX_VALUE))
		);
		
		JTextArea ChatBox_1 = new JTextArea();
		scrollPane.setViewportView(ChatBox_1);
		
		JMenuBar menuBar = new JMenuBar();
		scrollPane.setColumnHeaderView(menuBar);
		
		JMenuItem mntmInvite = new JMenuItem("Invite");
		menuBar.add(mntmInvite);
		
		JMenuItem mntmKickoff = new JMenuItem("KickOff");
		menuBar.add(mntmKickoff);
		
		JMenuItem mntmClose = new JMenuItem("Close");
		menuBar.add(mntmClose);
		
		JMenuItem mntmWho = new JMenuItem("Who");
		menuBar.add(mntmWho);
		
		JMenuItem mntmMute = new JMenuItem("Mute/Un");
		menuBar.add(mntmMute);
		this.setLayout(gl_panel);

	}


	public JTextField getClientIn() {
		return ClientIn;
	}


	public void setClientIn(JTextField clientIn) {
		ClientIn = clientIn;
	}


	public JTextArea getChatBox() {
		return ChatBox;
	}


	public void setChatBox(JTextArea chatBox) {
		ChatBox = chatBox;
	}






	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
	
		if(arg0.getSource() == this.mntmInvite) {
			USER.write(4, "GET_CLIENT_LIST", USER.getNAME(), this.getNAME(), "");
			this.getMSG().setText("Enter Name Here : ");
		
			}
		if(arg0.getSource()==ClientIn&&MSG.getText().equals("Enter Name Here : ")) {
		USER.write(4, "INVITE", this.USER.getNAME(), this.getNAME(),this.getClientIn().getText());
		this.getMSG().setText("Enter Message : ");
		this.ClientIn.setText("");
		return;
		}
		
		
		if(arg0.getSource()==ClientIn&&MSG.getText().equals("Kick Off ? : ")) {
			USER.write(4, "KICK_OFF", this.USER.getNAME(), this.getNAME(),this.getClientIn().getText());
			this.getMSG().setText("Enter Message : ");
			this.ClientIn.setText("");
			return;
		}
		
		if(arg0.getSource()==ClientIn&&MSG.getText().equals("Mute/Unmute ?")) {
			USER.write(4, "MUTE", this.USER.getNAME(), this.getNAME(),this.getClientIn().getText());
			this.getMSG().setText("Enter Message : ");
			this.ClientIn.setText("");
			return;
		}
		if(arg0.getSource()==ClientIn ) { 
		if(isMute == true) {
			ClientIn.setText("");
			return;
		}
		String s = this.ClientIn.getText();
		USER.write(3, s, USER.getNAME(), this.getNAME(),"");
		
		this.ClientIn.setText("");
		}
		
		
		
		if(arg0.getSource() == this.mntmClose) { 
			USER.write(4, "CLOSE", this.USER.getNAME(), this.getNAME(),"");
			//USER.getTabbedPane().remove(this);
			//USER.getTABS().remove(this.getNAME());
		}
		if(arg0.getSource() == this.mntmKickoff) {
			USER.write(4, "WHO", USER.getNAME(), this.getNAME(),"");
			this.getMSG().setText("Kick Off ? : ");
		}
		
		if(arg0.getSource() == this.mntmMute) {
			
			USER.write(4, "GET_CLIENT_LIST", USER.getNAME(), this.getNAME(), "");
			this.getMSG().setText("Mute/Unmute ?");
		
			}
		
		if(arg0.getSource() == this.mntmWho) {
			
			USER.write(4, "WHO", USER.getNAME(), this.getNAME(),"");
		}

	}

	public Client getUSER() {
		return USER;
	}

	public void setUSER(Client uSER) {
		USER = uSER;
	}

	public String getNAME() {
		return NAME;
	}

	public void setNAME(String nAME) {
		NAME = nAME;
	}


	public JLabel getMSG() {
		return MSG;
	}

	public void setMSG(JLabel mSG) {
		MSG = mSG;
	}

	public boolean isMute() {
		return isMute;
	}

	public void setMute(boolean isMute) {
		this.isMute = isMute;
	}

	
	}


