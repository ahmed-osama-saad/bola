package chat.guc.edu.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.MenuKeyListener;
import javax.swing.event.MenuKeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.swing.JTabbedPane;

public class ClientGUI extends JFrame implements ActionListener,ChangeListener{

	private JPanel contentPane;
	private JMenuBar menuBar;
	private JMenu mnFile;
	private JMenu mnEdit;
	private JMenu mnNew;
	public JMenuItem mntmChatRoom;
	public JMenuItem mntmWhoIsHere;
	private JMenuItem mntmExit;
	private JTabbedPane tabbedPane;
	private JPanel panel;
	private JScrollPane scrollPane;
	private JTextArea ChatBox;
	private JTextField ClientIn;
	private JLabel UserName;
	private ArrayList<Room> TABS;
	private boolean newRoom;
	private JMenuItem mntmChatroomList;
	private JMenuItem mntmJoin;
	private JMenuItem mntmPrivateChatRoom;
	private JMenu mnUpload;
	private JMenuItem mntmTcp;
	private JMenuItem mntmUdp;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClientGUI frame = new ClientGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ClientGUI() {
		setTitle("ChatRoom");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 728, 509);
		TABS = new ArrayList<Room>();
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		mnNew = new JMenu("New");
		mnFile.add(mnNew);
		
		mntmPrivateChatRoom = new JMenuItem("Private Chat Room");
		mnNew.add(mntmPrivateChatRoom);
		this.mntmPrivateChatRoom.addActionListener(this);
		
		mntmChatRoom = new JMenuItem("Public Chat Room");
		mnNew.add(mntmChatRoom);
		
		mntmJoin = new JMenuItem("Join");
		mnFile.add(mntmJoin);
		
		mnUpload = new JMenu("Upload");
		mnFile.add(mnUpload);
		
		mntmTcp = new JMenuItem("TCP");
		mnUpload.add(mntmTcp);
		mntmTcp.addActionListener(this);
		
		mntmUdp = new JMenuItem("UDP");
		mnUpload.add(mntmUdp);
		mntmUdp.addActionListener(this);
		
		mntmChatRoom.addActionListener(this);
		mnEdit = new JMenu("Options");
		menuBar.add(mnEdit);
		
		mntmWhoIsHere = new JMenuItem("Who is Here ?");
		mnEdit.add(mntmWhoIsHere);
		
		mntmChatroomList = new JMenuItem("ChatRoom List");
		mnEdit.add(mntmChatroomList);
		mntmChatroomList.addActionListener(this);
		
		
		mntmExit = new JMenuItem("Exit");
		mnEdit.add(mntmExit);
		mntmExit.addActionListener(this);
		
		this.getMntmWhoIsHere().addActionListener(this);
		this.getMntmJoin().addActionListener(this);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(1, 0, 0, 0));
		
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		contentPane.add(tabbedPane);
		tabbedPane.addChangeListener(this);
		panel = new JPanel();
		tabbedPane.addTab("Lobby", null, panel, null);
		
		scrollPane = new JScrollPane();
		
		ClientIn = new JTextField();
		ClientIn.setColumns(10);
		ClientIn.addActionListener(this);
	
		UserName = new JLabel("UserName : ");
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(ClientIn, GroupLayout.DEFAULT_SIZE, 687, Short.MAX_VALUE)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 687, Short.MAX_VALUE)
						.addComponent(UserName))
					.addContainerGap())
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(54)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 255, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(UserName)
					.addGap(13)
					.addComponent(ClientIn, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(47, Short.MAX_VALUE))
		);
		
		ChatBox = new JTextArea();
		scrollPane.setViewportView(ChatBox);
		panel.setLayout(gl_panel);
	}

	

	public JMenu getMnFile() {
		return mnFile;
	}

	public void setMnFile(JMenu mnFile) {
		this.mnFile = mnFile;
	}

	public JMenu getMnEdit() {
		return mnEdit;
	}

	public void setMnEdit(JMenu mnEdit) {
		this.mnEdit = mnEdit;
	}

	public JMenu getMnNew() {
		return mnNew;
	}

	public void setMnNew(JMenu mnNew) {
		this.mnNew = mnNew;
	}

	public JMenuItem getMntmChatRoom() {
		return mntmChatRoom;
	}
	
	

	public void setMntmChatRoom(JMenuItem mntmChatRoom) {
		this.mntmChatRoom = mntmChatRoom;
	}

	public JMenuItem getMntmWhoIsHere() {
		return mntmWhoIsHere;
	}

	public void setMntmWhoIsHere(JMenuItem mntmWhoIsHere) {
		this.mntmWhoIsHere = mntmWhoIsHere;
	}


	public void setMenuBar(JMenuBar menuBar) {
		this.menuBar = menuBar;
	}

	public JMenuItem getMntmExit() {
		return mntmExit;
	}

	public void setMntmExit(JMenuItem mntmExit) {
		this.mntmExit = mntmExit;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
	}
			

	public JTextArea getChatBox() {
		return ChatBox;
	}

	public void setChatBox(JTextArea chatBox) {
		ChatBox = chatBox;
	}

	public JTextField getClientIn() {
		return ClientIn;
	}

	public void setClientIn(JTextField clientIn) {
		ClientIn = clientIn;
	}

	public JLabel getUserName() {
		return UserName;
	}

	public void setUserName(JLabel userName) {
		UserName = userName;
	}

	@Override
	public void stateChanged(ChangeEvent arg0) {
		// TODO Auto-generated method stub
		
		
	}

	public JTabbedPane getTabbedPane() {
		return tabbedPane;
	}

	public void setTabbedPane(JTabbedPane tabbedPane) {
		this.tabbedPane = tabbedPane;
	}

	public ArrayList<Room> getTABS() {
		return TABS;
	}

	public void setTABS(ArrayList<Room> tABS) {
		TABS = tABS;
	}

	public boolean isNewRoom() {
		return newRoom;
	}

	public void setNewRoom(boolean newRoom) {
		this.newRoom = newRoom;
	}

	public JMenuItem getMntmChatroomList() {
		return mntmChatroomList;
	}

	public void setMntmChatroomList(JMenuItem mntmChatroomList) {
		this.mntmChatroomList = mntmChatroomList;
	}

	public JMenuItem getMntmJoin() {
		return mntmJoin;
	}

	public void setMntmJoin(JMenuItem mntmJoin) {
		this.mntmJoin = mntmJoin;
	}

	public JMenuItem getMntmPrivateChatRoom() {
		return mntmPrivateChatRoom;
	}

	public void setMntmPrivateChatRoom(JMenuItem mntmPrivateChatRoom) {
		this.mntmPrivateChatRoom = mntmPrivateChatRoom;
	}

	
	public JMenuItem getMntmTcp() {
		return mntmTcp;
	}

	public void setMntmTcp(JMenuItem mntmTcp) {
		this.mntmTcp = mntmTcp;
	}

	public JMenuItem getMntmUdp() {
		return mntmUdp;
	}

	public void setMntmUdp(JMenuItem mntmUdp) {
		this.mntmUdp = mntmUdp;
	}
	
	
	
	
}
