package chat.guc.edu.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class ServerGUI extends JFrame implements  ActionListener{
	
	public JTextArea getSER_ROOM() {
		return SER_ROOM;
	}

	public void setSER_ROOM(JTextArea sER_ROOM) {
		SER_ROOM = sER_ROOM;
	}

	public JTextArea getEVENT_LOG() {
		return EVENT_LOG;
	}

	public void setEVENT_LOG(JTextArea eVENT_LOG) {
		EVENT_LOG = eVENT_LOG;
	}

	private JTextArea SER_ROOM;
	private JTextArea EVENT_LOG;
	
	
	public ServerGUI() {
		
		setTitle("SERVERGUI");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 12, 424, 305);
		getContentPane().add(scrollPane);
		
		SER_ROOM = new JTextArea();
		SER_ROOM.setText("Server Lobby");
		scrollPane.setViewportView(SER_ROOM);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(12, 329, 424, 300);
		getContentPane().add(scrollPane_1);
		
		EVENT_LOG = new JTextArea();
		EVENT_LOG.setText("Event Log");
		scrollPane_1.setViewportView(EVENT_LOG);
		this.getContentPane().setPreferredSize(new Dimension(450,650));
		this.pack();
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}