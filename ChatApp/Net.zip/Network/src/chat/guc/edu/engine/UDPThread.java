package chat.guc.edu.engine;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

import javax.swing.JFileChooser;
import javax.swing.JTextArea;


public class UDPThread extends Thread {
private DatagramSocket socket;
private int bLength;
private Server LOBBY;
private String sName;
private String rName;
private String fName;
private char mode;
private JTextArea box;
private int sTime;

public UDPThread(DatagramSocket socket,int b,Server L,String rName,String sName,String fName) {
    
	System.out.println("constructor");
	mode = 's';
    this.socket = socket;
    bLength = b;
    LOBBY = L;
    this.sName = sName;
    this.rName = rName;
    this.fName = fName;
    
}

public UDPThread(DatagramSocket socket, int b,String fName,JTextArea ChatBox,int s) {
	
	mode = 'c';
    this.socket = socket;
    bLength = b;
    this.fName = fName;
    box = ChatBox;
    sTime = s;
	
}

@Override
public void run() {
	
	if(mode == 's') {
    byte[] buffer = new byte[bLength];
    System.out.println("run");
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        try {
			socket.receive(packet);
			LOBBY.getCLIENTS().get(sName).write(2, "", "","", "");
			System.out.println("packet recieved");
			String strFileContent = new String(packet.getData()); 
		    System.out.println("File content At server UDP mind you ! : ");
		    System.out.println(strFileContent);
			LOBBY.getUDP_FILES().put(rName,packet.getData());
			LOBBY.getEVENT_LOG().append(sName + " : " + "UPLOAD_UDP" + " request handled" + "\n");
			LOBBY.getCLIENTS().get(rName).write(2, "UPLOAD_UDP","Server/Thread/" + sName,rName,fName);
			LOBBY.getEVENT_LOG().append(sName + " : " + "UPLOAD_UDP" + " request sent to " + rName +  "\n");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        socket.close();
	}
	else {
		 
		 byte[] buffer = new byte[bLength];
		 System.out.println("run");
		 DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
		 
			 try {
			 
		     socket.receive(packet);
		     
		     box.append("Time to download file from server in UDP " + ((int)System.currentTimeMillis() - sTime)/1000.000000000);
			 System.out.println("packet recieved");
			 String strFileContent = new String(packet.getData()); 
			 System.out.println("File content At reciveing client UDP mind you ! : ");
			 System.out.println(strFileContent);
			 JFileChooser chooser = new JFileChooser();
			 chooser.showOpenDialog(null);
			 String b []  = chooser.getSelectedFile().getAbsolutePath().split("/");
			 String target = "";
			 for(int i = 0; i < b.length-1; i++)
				 target+=b[i]+"//";
		
			 target += fName;
			 File x = new File(target);
			 FileOutputStream fos = new FileOutputStream(x);
			 fos.write(packet.getData());
			 fos.close();
			 packet = null;
			 socket.close();
			 
			 }
			 
			 catch (IOException i) {
				 System.out.println(i.getMessage());
			 }
	
        
		}

	}

}