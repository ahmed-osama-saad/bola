package chat.guc.edu.engine;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;

import chat.guc.edu.exceptions.ClientErrorException;
import chat.guc.edu.gui.Room;


public class ThreadSocket extends Thread {
	
	private long THREAD_ID;
	private Socket TH_SOCKET;
	private ObjectInputStream OIS;
	private ObjectOutputStream OOS; 
	private BufferedReader br;
	private Server LOBBY;
	private String CLIENT_NAME;
	private boolean isAdmin;
	private DatagramSocket D_TH_SOCKET;
	
	public ThreadSocket(Socket s, Server S) {
		try { 
		LOBBY = S;
		TH_SOCKET = s;
		THREAD_ID = this.getId();
		OIS = new ObjectInputStream(TH_SOCKET.getInputStream());
		OOS = new ObjectOutputStream(TH_SOCKET.getOutputStream());
		br = new BufferedReader(new InputStreamReader(System.in));
	
		}
		
		catch(Exception e) { 
			
		}
		
	
		}
	

	public Message read() {
		
		Message m;
		try {
			m = (Message)OIS.readObject();
			return m;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			LOBBY.getEVENT_LOG().append("Client " + this.CLIENT_NAME + " has disconnected" + "\n"+  e.getMessage() + "\n");
			close();
			return null;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			LOBBY.getEVENT_LOG().append("Client Disconnected " + e.getMessage() + "\n");
			close();
			return null;
		}

		
	}
	
	public void write(int t, String r, String src, String dst, String i) {
			
		try {
			OOS.writeObject(new Message(t, r, src, dst, i));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			LOBBY.getEVENT_LOG().append(e.getMessage() + "\n");
		}
		
	}
	public void write(int t, String r, String src, String dst, String i,Object o) {
		
		try {
			OOS.writeObject(new Message(t, r, src, dst, i,o));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			LOBBY.getEVENT_LOG().append(e.getMessage() + "\n");
		}
		
	}
	
	public void close() {
		
		try { 	
		OIS.close();
		OOS.close();
		TH_SOCKET.close(); 
		}
		
		catch(Exception e) {
			e.printStackTrace();
	 	}
	}
	
	public boolean isClosed() {
		
		return TH_SOCKET.isClosed();
	}


	public void run() {
		
		
		Message M;
		
		
		while(true) { 
			
			M = read();
			if(M==null)
				break;
			
			handleMessage(M);
			}
		}

		
				
	
	public boolean handleMessage(Message M) {
		
		if(M.getTYPE() == 0 ) {
			System.out.println(M==null);
			System.out.println(M.getInfo());
			System.out.println(LOBBY.getClientNames());
		if(LOBBY.getCLIENTS().containsKey(M.getInfo())) {
			
				write(5,"CONNECT","Server","","Connect To Server Request denied... Use another Name");
				return true;
				}
		
		CLIENT_NAME = M.getInfo();
		LOBBY.getCLIENTS().put(CLIENT_NAME,this);
		LOBBY.getEVENT_LOG().append("Connection initiated with :" + CLIENT_NAME + "\n");
		write(1,"Welcome " + CLIENT_NAME,"Server/Thread/" + CLIENT_NAME,"CLIENT/"+CLIENT_NAME,"");
		return true;
		}
		if(M.getTYPE()==1){
			
			LOBBY.getSER_ROOM().append(M.getSrc() + " : " + M.getMSG() + "\n");			
			send(M);
			return true;
			}
		
		if(M.getTYPE()==2) {
			
			if(M.getMSG().equals("GET_CLIENT_LIST")) { 
					write(2,"CLIENT_LIST", "Server", "Server/Thread/" + CLIENT_NAME,LOBBY.getClientNames());
					LOBBY.getEVENT_LOG().append(M.src + " : " + M.getMSG() + " request handled" + "\n");
			}
			
			if(M.getMSG().equals("GET_CHAT_ROOM_LIST")) {
				write(2,"CHAT_ROOM_LIST", "Server", "Server/Thread/" + CLIENT_NAME,LOBBY.getChatRoomList());
				LOBBY.getEVENT_LOG().append(M.src + " : " + M.getMSG() + " request handled" + "\n");
			}
			
			if(M.getMSG().equals("CREATE_CHAT_ROOM")) { 
				ChatRoom C = new ChatRoom(LOBBY.getByName(CLIENT_NAME),new ArrayList<ThreadSocket>(),false,M.getInfo());
				C.getMEMBERS().add(this);
				this.isAdmin = true;
				LOBBY.getROOMS().put(M.getInfo(),C);
				LOBBY.getEVENT_LOG().append(M.src + " : " + M.getMSG() + " request handled" + "\n");
				write(2,"CHAT_ROOM","Server","Server/Thread/" + CLIENT_NAME,M.getInfo());
				return true;
			}
			if(M.getMSG().equals("CREATE_CHAT_ROOM_P")){
				ChatRoom C = new ChatRoom(LOBBY.getByName(CLIENT_NAME),new ArrayList<ThreadSocket>(),true,M.getInfo());
				C.getMEMBERS().add(this);
				this.isAdmin = true;
				LOBBY.getROOMS().put(M.getInfo(),C);
				LOBBY.getEVENT_LOG().append(M.src + " : " + M.getMSG() + " request handled" + "\n");
				write(2,"CHAT_ROOM_P","Server","Server/Thread/" + CLIENT_NAME,M.getInfo());
				return true;
			}
			if(M.getMSG().equals("JOIN_CHAT_ROOM")){
				System.out.println(M.getInfo());
				if(!(LOBBY.getROOMS().containsKey(M.getInfo()))) {
					write(5,"JOIN_ROOM","Server","Server/Thread/" + CLIENT_NAME,"Chat Room Does Not Exist !");
					LOBBY.getEVENT_LOG().append(M.src + " : " + M.getMSG() + " request Denied" + "\n");
					return true;
				}
				else{	
				LOBBY.getROOMS().get(M.getInfo()).addMember(this);
				write(2,"JOIN_ROOM","Server","Server/Thread/" + CLIENT_NAME,M.getInfo());
				LOBBY.getEVENT_LOG().append(M.src + " : " + M.getMSG() + " request handled" + "\n");
				return true;
				}
			}
			
			if(M.getMSG().equals("CLOSE")) {
				send(new Message(4,"CLOSE_ALL",M.getSrc(),M.getDst(),""));
				if(LOBBY.getCLIENTS().get(M.getSrc()).isAdmin())
					removeChatRooms(CLIENT_NAME);
				LOBBY.getCLIENTS().remove(CLIENT_NAME);
				LOBBY.getEVENT_LOG().append(M.src + " : " + M.getMSG() + " request handled" + "\n");
				return true;
			}
			
		
		}
		if(M.getTYPE() == 3) {
			
			LOBBY.getSER_ROOM().append(M.getDst()+"/"+M.getSrc() + " : " + M.getMSG() + "\n");			
			send(M);
			return true;
		}
		
		if(M.getTYPE() == 4) {
			System.out.println(M.getMSG());
			if(M.getMSG().equals("CLOSE")) {
				if(LOBBY.getByName(M.getSrc()).isAdmin()) {
					send(new Message(4,"CLOSE",M.getSrc(),M.getDst(),""));
					LOBBY.getROOMS().remove(M.getDst());
					LOBBY.getEVENT_LOG().append(M.getSrc() + " : " + M.getMSG() + " request handled" + "\n" + M.getSrc() + "has deleted ChatRoom " + M.getDst() + " from the Server" + "\n");
					return true;
				}
				else {
					write(4, "CLOSE", M.getSrc(), M.getDst(),"");
					LOBBY.getROOMS().get(M.getDst()).removeMember(M.getMSG());
					LOBBY.getEVENT_LOG().append(M.getSrc() + " : " + M.getMSG() + " request handled" + "\n" + M.getSrc() + "has exited from chatRoom " + M.getDst() + "\n");
					return true;
				}
				
			}
			
			if(M.getMSG().equals("WHO")) {
				
				LOBBY.getEVENT_LOG().append(M.getSrc() + " : " + M.getMSG() + " request handled" + "\n" + M.getSrc() + "Member list sent to " + M.getDst() + "\n");
				LOBBY.getCLIENTS().get(M.getSrc()).write(4,"MEMBER_LIST",M.getSrc(),M.getDst(),LOBBY.getROOMS().get(M.getDst()).getMemberList());
				return true;
			}
			if(M.getMSG().equals("GET_CLIENT_LIST")){
				write(4,"CLIENT_LIST", M.getSrc(),M.getDst(),LOBBY.getClientNames());
				LOBBY.getEVENT_LOG().append(M.dst+"/"+M.src + " : " + M.getMSG() + " request handled" + "\n");
			}
			if(M.getMSG().equals("INVITE")) {
			
					LOBBY.getROOMS().get(M.getDst()).getMEMBERS().add(LOBBY.getCLIENTS().get(M.getInfo()));
					LOBBY.getCLIENTS().get(M.getInfo()).write(4,"INVITE", M.getSrc(),M.getDst(),M.getDst());
					LOBBY.getEVENT_LOG().append(M.dst+"/"+M.src + " : " + M.getMSG() + " request handled" + "\n");
					return true;
				
				
			}
			
		
		if(M.getMSG().equals("KICK_OFF"))
		{
			if(!LOBBY.getCLIENTS().get(M.getSrc()).isAdmin()) { 
				LOBBY.getCLIENTS().get(M.getSrc()).write(5,"KICK_OFF", M.getSrc(),M.getDst(),"You are Not an Admin of this ChatRoom ! you cannot kickoff !");
				LOBBY.getEVENT_LOG().append(M.getSrc() + " : " + M.getMSG() + " request Denied" + "\n" + M.getSrc() + "Not an Admin " + M.getDst() + "\n");
				return true;
			}
			else
			{	
				LOBBY.getROOMS().get(M.getDst()).getMEMBERS().remove(LOBBY.getCLIENTS().get(M.getInfo()));
				LOBBY.getCLIENTS().get(M.getInfo()).write(4, "CLOSE", M.getSrc(), M.getDst(),"");
				LOBBY.getCLIENTS().get(M.getInfo()).write(4,"KICK_OFF", "Server",M.getDst(),"You just got Kicked off from ChatRoom " + M.getDst() +" by" + M.getSrc());
				LOBBY.getEVENT_LOG().append(M.dst+"/"+M.src + " : " + M.getMSG() + " request handled" + "\n");
				return true;
			}
			
		
			}
		
		
		if(M.getMSG().equals("MUTE"))
		{
			if(!LOBBY.getCLIENTS().get(M.getSrc()).isAdmin()) { 
				LOBBY.getCLIENTS().get(M.getSrc()).write(5,"MUTE", M.getSrc(),M.getDst(),"You are Not an Admin of this ChatRoom ! you cannot mute unmute anyone !");
				LOBBY.getEVENT_LOG().append(M.getSrc() + " : " + M.getMSG() + " request Denied" + "\n" + M.getSrc() + "Not an Admin " + M.getDst() + "\n");
				return true;
			}
			else
			{	
				LOBBY.getCLIENTS().get(M.getInfo()).write(4, "MUTE", "Server", "Server/Thread/" + CLIENT_NAME,M.getDst());
				LOBBY.getEVENT_LOG().append(M.dst+"/"+M.src + " : " + M.getMSG() + " request handled" + "\n");
				return true;
			}
			
		
			}
		}
		
		
		if(M.getTYPE()==6) {
			
	
			
			if(M.getMSG().equals("UPLOAD_TCP")) {
				
				write(2,"","","","");
				if(!LOBBY.getCLIENTS().containsKey(M.getInfo())) {
					LOBBY.getCLIENTS().get(M.getSrc()).write(5,"UPLOAD", M.getSrc(),M.getDst(),"Client Not logged On or Invalid client Name");
					return true;
				}
			
			
			/*
			try{ 
				File f = (File)M.getOMSG();
				FileInputStream fin = new FileInputStream(f);
			     
			   
			     
			       byte fileContent[] = new byte[(int)f.length()];
			     
			    
			       fin.read(fileContent);
			  
			       String strFileContent = new String(fileContent);
			     
			       System.out.println("File content At server : ");
			       System.out.println(strFileContent);
			     
			    }
			    catch(FileNotFoundException e)
			    {
			      System.out.println("File not found" + e);
			    }
			    catch(IOException ioe)
			    {
			      System.out.println("Exception while reading the file " + ioe);
			    }*/
			LOBBY.getTCP_FILES().put(M.getInfo(), (File) M.getOMSG());
			LOBBY.getEVENT_LOG().append(M.src + " : " + M.getMSG() + " request handled" + "\n");
			LOBBY.getCLIENTS().get(M.getInfo()).write(2, "UPLOAD_TCP","Server/Thread/" + M.getSrc(),M.getInfo(),M.getDst());
			LOBBY.getEVENT_LOG().append(M.src + " : " + M.getMSG() + " request sent to " + M.getInfo() +  "\n");
			return true;
			}
			
			if(M.getMSG().equals("UPLOAD_UDP")) {
				try {
					
					new UDPThread(new DatagramSocket(1254),Integer.parseInt(M.getSrc()),LOBBY,M.getInfo(),CLIENT_NAME,M.getDst()).start();
					write(6,"","","","");
					return true;
					
					
				} catch (SocketException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				
				catch(IOException i) {
					System.out.println(i.getMessage());
				}
				
			}
			
			if(M.getMSG().isEmpty()) {
				
				try {
					D_TH_SOCKET = new DatagramSocket();
					InetAddress r = InetAddress.getByName("127.0.0.1");
					D_TH_SOCKET.send(new DatagramPacket(LOBBY.getUDP_FILES().get(CLIENT_NAME),LOBBY.getUDP_FILES().get(CLIENT_NAME).length,r,1254));
					System.out.println("packet sent from server");
					D_TH_SOCKET.close();
				} catch (SocketException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				catch(UnknownHostException u) {
					
				}
				catch(IOException i1) {
					
				}
								
			}
			if(M.getMSG().equals("ACCEPT_TCP")) {
				
				write(6,"FILE_TCP","Server","Server/Thread/" + CLIENT_NAME,"",LOBBY.getTCP_FILES().get(M.getInfo()));
				LOBBY.getEVENT_LOG().append(M.src + " : " + M.getMSG() + " file request handled" + "\n");
				return true;
			}
			

			if(M.getMSG().equals("REJECT_TCP")) {
				
				LOBBY.getTCP_FILES().remove(M.getInfo());
				LOBBY.getEVENT_LOG().append(M.src + " : " + M.getMSG() + " file request handled" + "\n");
				return true;
			}
			
			if(M.getMSG().equals("ACCEPT_UDP")) {
				
				write(6,"FILE_UDP","Server","Server/Thread/" + CLIENT_NAME,""+LOBBY.getUDP_FILES().get(M.getInfo()).length);
				LOBBY.getEVENT_LOG().append(M.src + " : " + M.getMSG() + " file request handled" + "\n");
				return true;
			}
			
			if(M.getMSG().equals("REJECT_UDP")) {
				
				LOBBY.getUDP_FILES().remove(M.getInfo());
				LOBBY.getEVENT_LOG().append(M.src + " : " + M.getMSG() + " file request handled" + "\n");
				return true;
			}
		}
			
			
		
		
	
			
	
		
		return false;
		
			
		//to be continued
		
		
	
		
			
		
			
		
			
		
	}


	public Server getLOBBY() {
		return LOBBY;
	}


	public void setLOBBY(Server lOBBY) {
		LOBBY = lOBBY;
	}


	public String getCLIENT_NAME() {
		return CLIENT_NAME;
	}


	public void setCLIENT_NAME(String cLIENT_NAME) {
		CLIENT_NAME = cLIENT_NAME;
	}
	
	public synchronized void send(Message m) {
		
		Object threads[];
		Collection val = LOBBY.getCLIENTS().values();
		threads =  val.toArray();
		if(m.getTYPE()==1) {
		for(Object current : threads) { 
			((ThreadSocket)current).write(1, m.getMSG(),this.getCLIENT_NAME(), ((ThreadSocket) current).getCLIENT_NAME(),"");
			}
		}
		if(m.getTYPE()==3)
			LOBBY.getROOMS().get(m.getDst()).send(m);
		if(m.getTYPE()==4) {
			if(m.getMSG().equals("CLOSE"))
			LOBBY.getROOMS().get(m.getDst()).send(m);
			if(m.getMSG().equals("CLOSE_ALL")) { 
				 Collection rooms = LOBBY.getROOMS().values();
			        Object objects[] = rooms.toArray();
			        for ( Object object : objects )
			           ((ChatRoom)object).send(new Message(4,"CLOSE",m.getSrc(),((ChatRoom)object).getName(),""));	  
				}
		}
		
			
	}


	public boolean isAdmin() {
		return isAdmin;
	}


	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}
	
	public void removeChatRooms(String n) {
		
		int i = 1;
		
		while(LOBBY.getROOMS().containsKey(this.getCLIENT_NAME()+"/"+i)) 
			LOBBY.getROOMS().remove(this.getCLIENT_NAME()+"/"+i);

	
}
	
	

}

		 
				
								
				
				
				
				
	

