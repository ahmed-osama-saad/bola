

package chat.guc.edu.engine;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;

import javax.swing.JFileChooser;

import chat.guc.edu.gui.*;

public class Main {
	


	
	public static void main(String [] args) throws IOException {
		//displayTime();
		
		 
		
		Server S1;

		S1 = new Server("server1",1254);
		while(true)
			S1.listen();
			
				
		
		
		
		
		/*JFileChooser c = new JFileChooser();
		c.showOpenDialog(null);
		try{ 
			   File f = c.getSelectedFile();
			   FileInputStream fin = new FileInputStream(f);
			   System.out.println(f.getAbsolutePath());
		       byte fileContent[] = new byte[(int)f.length()];
		      File f2 = new File("//Users//mohammadabdulkhaliq//Hell.sh");
		      FileOutputStream fos = new FileOutputStream(f2);
		      
		       fin.read(fileContent);
		       fos.write(fileContent);
		      
		     
		    }
		    catch(FileNotFoundException e)
		    {
		      System.out.println("File not found" + e);
		    }
		    catch(IOException ioe)
		    {
		      System.out.println("Exception while reading the file " + ioe);
		    }
		*/
		
		
		
		
	}
	
	public static void displayTime(){
		 Date date = new Date();
		    System.out.println(date);
		    //System.out.println(date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds());
		    long t1 = date.getTime();
		    System.out.println((t1 / 1000 / 60 / 60) % 24 + ":" + (t1 / 1000 / 60) % 60 + ":" + (t1 / 1000) % 60);
		    long t2 = System.currentTimeMillis();
		    System.out.println((t2 / 1000 / 60 / 60) % 24 + ":" + (t2 / 1000 / 60) % 60 + ":" + (t2 / 1000) % 60);
		
		
	}
	
	
	
	
	
	
}
