package chat.guc.edu.engine;
import java.net.*;
import java.awt.event.ActionEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Queue;


import chat.guc.edu.gui.Room;
import chat.guc.edu.gui.ServerGUI;
public class Server extends ServerGUI {
	
	private ServerSocket SER_SOCKET;
	private String NAME;
	private  Hashtable<String,ThreadSocket> CLIENTS;
	private Hashtable<String, ChatRoom> ROOMS;
	private Hashtable <String,File> TCP_FILES;
	private Hashtable <String,byte[]> UDP_FILES;
	private boolean RUNNING;
	public Server (String name, int portNo) throws IOException {

		setNAME(name);
		SER_SOCKET = new ServerSocket(1254);
		CLIENTS = new Hashtable<String,ThreadSocket>();
		ROOMS = new Hashtable<String,ChatRoom>();
		TCP_FILES = new Hashtable<String,File>();
		UDP_FILES = new Hashtable<String, byte[]> ();
		
		this.addWindowListener(new WindowListener() {																		// Window Listener for safe closure of socket and inout streams 
			@Override
			public void windowActivated(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowClosed(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowClosing(WindowEvent arg0) {																// Window closing event
				// TODO Auto-generated method stub
				
				// dispose the frame
				SER_SOCKET = null;
				CLIENTS = null;
				ROOMS = null;
				dispose();
				System.exit(0);;
			}

			@Override
			public void windowDeactivated(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowDeiconified(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowIconified(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowOpened(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

		});
		setVisible(true);
	}
	
	

	public String getNAME() {
		return NAME;
	}



	public void setNAME(String nAME) {
		NAME = nAME;
	}
	
	public void listen() {
		RUNNING = true;
		try { 
		Socket S = SER_SOCKET.accept();
		ThreadSocket newClient = new ThreadSocket(S, this);
		//addClient(newClient);
		newClient.start();
		//System.out.println(newClient.getCLIENT_NAME());
		}
		catch(IOException i) {
			
			
		}
	}

	
	
	public void removeClient(ThreadSocket s) {
		
		CLIENTS.remove(s);
	}



	public Hashtable<String, ThreadSocket> getCLIENTS() {
		return CLIENTS;
	}



	public void setCLIENTS(Hashtable<String, ThreadSocket> cLIENTS) {
		CLIENTS = cLIENTS;
	}
	
	public String getClientNames() {
		
		String res = "";
		int i = 1;
		Enumeration<String> keys = CLIENTS.keys();
	       while (keys.hasMoreElements()) {
	            Object key = keys.nextElement();
	            res += i + ") " + key;
	        }
		return res;
	}
	
	public String getChatRoomList() {

		String res = "";
		int i = 1;
		Enumeration<String> keys = ROOMS.keys();
	       while (keys.hasMoreElements()) {
	            Object key = keys.nextElement();
	            if(!ROOMS.get(key).PRIVATE)
	            res += i + ") " + key;
	        }
		return res;
	}
	
	
	public void close() { 
		
		if(RUNNING) { 
			try {
				SER_SOCKET.close();
				dispose();
				System.exit(0);
				
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
		else
			dispose();
			System.exit(0);
		
		
	}
	
	public boolean checkName(String n) {
		
			return CLIENTS.containsKey(n);
		
		}



	public Hashtable<String, ChatRoom> getROOMS() {
		return ROOMS;
	}



	public void setROOMS(Hashtable<String, ChatRoom> rOOMS) {
		ROOMS = rOOMS;
	}
	
	public ThreadSocket getByName(String n) {
		
			return CLIENTS.get(n);
				
			
			
		}






	public Hashtable<String, File> getTCP_FILES() {
		return TCP_FILES;
	}



	public void setTCP_FILES(Hashtable<String, File> tCP_FILES) {
		TCP_FILES = tCP_FILES;
	}



	public Hashtable<String, byte[]> getUDP_FILES() {
		return UDP_FILES;
	}



	public void setUDP_FILES(Hashtable<String, byte[]> uDP_FILES) {
		UDP_FILES = uDP_FILES;
	}
	}
	

	



		
		
	


