package chat.guc.edu.engine;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
/*
 * ChatRoom Class is an abstract collection of Data representing chatRooms
 * on the Server Side it simply holds records of the Members and Admin ide
 * -ntities as ThreadSockets
 */

public class ChatRoom {
	
	String Name;
	ThreadSocket ADMIN;
	ArrayList<ThreadSocket> MEMBERS;
	boolean PRIVATE;                  
	
	public ChatRoom(ThreadSocket Ad, ArrayList<ThreadSocket> m,boolean p,String N) {
		
		ADMIN = Ad;
		Name = N;
		MEMBERS = m;
		PRIVATE = p;
		
	}

	public ThreadSocket getADMIN() {
		return ADMIN;
	}

	public void setADMIN(ThreadSocket aDMIN) {
		ADMIN = aDMIN;
	}

	public ArrayList<ThreadSocket> getMEMBERS() {
		return MEMBERS;
	}

	public void setMEMBERS(ArrayList<ThreadSocket> mEMBERS) {
		MEMBERS = mEMBERS;
	}



	
	public void addMember(ThreadSocket member) {
		
		MEMBERS.add(member);
	}
	
	public void removeMember(String n) {
		
		MEMBERS.remove(n);
		
	}
	
	public synchronized void send(Message M) {     //Messages to be sent only to members of the ChatRoom
		
		
		
		if(M.getTYPE() == 3) { 
		for(ThreadSocket current : MEMBERS) { 
			current.write(3, M.getMSG(),M.getSrc(), M.getDst(),"");  //iterating over ThreadSockets members and sending messages to their respective clients
			System.out.println(current.getCLIENT_NAME());      
			}
		}
		if(M.getTYPE() == 4) {
			if(M.getMSG().equals("CLOSE"))
				for(ThreadSocket current : MEMBERS) { 
					current.write(4, M.getMSG(),M.getSrc(), M.getDst(),"");
					}
			}
		
			
		}
	
	public synchronized void kickOff(String n) {
		
	}


	
	public ThreadSocket search(String n) { //search for a particular member
		for(ThreadSocket current : MEMBERS) 
			if(current.getCLIENT_NAME().equals(n))
				return current;
			
			return null;
	}
	
	public String getMemberList() {
		String res = "";
		int i = 1;
		for(ThreadSocket current : MEMBERS) { 
			res+=i+")" + current.getCLIENT_NAME() +"\n";
					i++;
		}
		return res;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
	
	
		
	}
	

	
	
	
	
	
	
	
	

