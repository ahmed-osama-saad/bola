package chat.guc.edu.engine;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.*;
import java.net.*;
import java.nio.channels.FileChannel;
import java.util.Date;

import javax.swing.JFileChooser;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;

import chat.guc.edu.exceptions.*;

import chat.guc.edu.gui.*;

public class Client extends ClientGUI implements Runnable {

	private String NAME; 											
	private int CLIENT_ID;																									//Unique id for every client should be linked to a server data structure
	private Socket CL_SOCKET;
	private DatagramSocket D_SOCKET;
	private int PORT_NO;
	private String SERVER_IP;
	private ObjectInputStream OIS;
	private ObjectOutputStream OOS;
	private  boolean CONNECTED;
	private int roomCount;
	private JFileChooser chooser;
	private File filePath;
	private String fileName;
	private long stime;
	private long etime;
	
	
	public Client() {																										// default constructor for user specified ips and ports 
		
		CONNECTED = false;      
		PORT_NO = -1;	
		SERVER_IP = "";
		chooser = new JFileChooser();
		this.addWindowListener(new WindowListener() {																		// Window Listener for safe closure of socket and inout streams 
			@Override
			public void windowActivated(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowClosed(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowClosing(WindowEvent arg0) {																// Window closing event
				// TODO Auto-generated method stub
				close();
			}

			@Override
			public void windowDeactivated(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowDeiconified(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowIconified(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowOpened(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

		});
		this.setVisible(true);

	}

	public Client(String ServerIp, int portNo) {																						//Overloaded constructor for simple use in main() 

		CONNECTED = false;
		PORT_NO = portNo;
		SERVER_IP = ServerIp;
		chooser = new JFileChooser();
		
		/*this.getServerName().setText(ServerIp);																						
		this.getPortNo().setText(portNo + "");
		this.getServerName().setEditable(false);
		this.getPortNo().setEditable(false);*/
		
		this.addWindowListener(new WindowListener() {
			@Override
			public void windowActivated(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowClosed(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowClosing(WindowEvent arg0) {
				// TODO Auto-generated method stub
				close();
			}

			@Override
			public void windowDeactivated(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowDeiconified(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowIconified(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowOpened(WindowEvent arg0) {
				// TODO Auto-generated method stub

			}

		});
		
		this.setVisible(true);

	}

	public String getNAME() {
		return NAME;
	}

	public void setNAME(String nAME) {
		NAME = nAME;
	}

	public int getCLIENT_ID() {
		return CLIENT_ID;
	}

	public void setCLIENT_ID(int cLIENT_ID) {
		CLIENT_ID = cLIENT_ID;
	}

	public Message read() {																													//encapsulation of .readUTF() in read method 

		try {
			Message m = (Message) OIS.readObject();
			return m;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			this.getChatBox().append("Server Down" + "\n" + e.getMessage());																//exception messages displayed on gui 
			return null;
		}
		catch(ClassNotFoundException c) {
			this.getChatBox().append("Server Down" + "\n" + c.getMessage());
			return null;
		}

	}

	public void write(int t, String r, String src, String dst, String i) {
		try {
			OOS.writeObject(new Message(t, r, src, dst, i));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			this.getChatBox().append(e.getMessage() + "\n ....");
		}

	}
	
	public void write(int t, String r, String src, String dst, String i,Object o) {
		try {
			OOS.writeObject(new Message(t, r, src, dst, i,o));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			this.getChatBox().append(e.getMessage() + "\n ....");
		}

	}

	public void close() {																												//closing method for releasing resources

		this.dispose();
		
		try {
			
			if(CONNECTED) {
			write(2, "CLOSE", NAME, "Server","");
			CONNECTED = false;
			OIS.close();
			OOS.close();
			CL_SOCKET.close(); 
			System.out.println("Client logged out ...");
			System.exit(0);
			}
			System.out.println("Client timed out !");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	

	}

	public void makeConnection() {																									//connection initialization method 

		try {
			if (SERVER_IP == "" || PORT_NO == -1)																					// User exception to be handled
				throw new ClientErrorException(
						"Server Ip or port_no invalid please try again");

			CL_SOCKET = new Socket(SERVER_IP, PORT_NO);
			OOS = new ObjectOutputStream(CL_SOCKET.getOutputStream());
			OIS = new ObjectInputStream(CL_SOCKET.getInputStream());
			CONNECTED = true;
			this.getChatBox().append("Connection established ..." + "\n");
			new Thread(this).start();
		

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			this.getChatBox().setText(e.getMessage() + "\n" +"..." + "\n" + "Please Close Window and try again !");
			this.getClientIn().setEditable(false);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			this.getChatBox().setText(e.getMessage() + "\n ..." + "Please Close Window and try again !");
			this.getClientIn().setEditable(false);
		}

	}

	public static void main(String[] args) {
		
		Client C1 = new Client("127.0.0.1", 1254);
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) { 																				//Overridden method from ActionListener interface 
		// TODO Auto-generated method stub
		Object Ob = e.getSource();
		
		if(Ob == this.getMntmWhoIsHere() && CONNECTED)
			write(2,"GET_CLIENT_LIST",NAME,"Server","");
		
		if(Ob == this.getMntmChatRoom())  {
			write(2,"CREATE_CHAT_ROOM",NAME,"Server",this.NAME + "/"+roomCount);
			roomCount++;
		}
		if(Ob == this.getMntmPrivateChatRoom() && CONNECTED) {
			write(2,"CREATE_CHAT_ROOM_P",NAME,"Server",this.NAME + "/"+roomCount);
			roomCount++;
		}
		if(Ob == this.getMntmJoin()&&CONNECTED) {
			write(2,"GET_CHAT_ROOM_LIST",NAME,"Server","");
			this.getUserName().setText("Enter Chat Room You wish to join ! :");
			return;
		}
		
		if(Ob == this.getMntmChatroomList() && CONNECTED)
			write(2,"GET_CHAT_ROOM_LIST",NAME,"Server","");
		
		if(Ob == this.getMntmTcp() && CONNECTED) { 
			chooser.showOpenDialog(null);
			filePath = chooser.getSelectedFile();
			if(filePath==null)
				return;
			
			/*try{ 
				FileInputStream fin = new FileInputStream(filePath);
			     
			   
			     
			       byte fileContent[] = new byte[(int)filePath.length()];
			     
			    
			       fin.read(fileContent);
			     
			       //create string from byte array
			       String strFileContent = new String(fileContent);
			     
			       System.out.println("File content At Sending Client: ");
			       System.out.println(strFileContent);
			     
			    }
			    catch(FileNotFoundException e1)
			    {
			      System.out.println("File not found" + e);
			    }
			    catch(IOException ioe)
			    {
			      System.out.println("Exception while reading the file " + ioe);
			    }*/ //Display File Encoding and Name , if neccessary uncomment block, however severe overload
			
			String filename = filePath.getName();
			System.out.println("You have selected: " + filename);
			this.getUserName().setText("Enter Name of Person you wish to send the file over TCP protocol");
		}
		
		if(Ob == this.getMntmUdp() && CONNECTED) { 
			chooser.showOpenDialog(null);
			filePath = chooser.getSelectedFile();
			if(filePath==null)
				return;
			
			/*try{ 
				FileInputStream fin = new FileInputStream(filePath);
			     
			   
			     
			       byte fileContent[] = new byte[(int)filePath.length()];
			     
			    
			       fin.read(fileContent);
			     
			       //create string from byte array
			       String strFileContent = new String(fileContent);
			     
			       System.out.println("File content At Sending Client: ");
			       System.out.println(strFileContent);
			     
			    }
			    catch(FileNotFoundException e1)
			    {
			      System.out.println("File not found" + e);
			    }
			    catch(IOException ioe)
			    {
			      System.out.println("Exception while reading the file " + ioe);
			    }*/ //Display File Encoding and Name , if neccessary uncomment block, however severe overload
			
			String filename = filePath.getName();
			System.out.println("You have selected: " + filename);
			this.getUserName().setText("Enter Name of Person you wish to send the file over UDP protocol");
		}
		
		if (Ob == this.getClientIn()
				&& this.getUserName().getText().equals("Enter Name of Person you wish to send the file over TCP protocol") && CONNECTED) {
			
			stime = System.currentTimeMillis();
			write(6,"UPLOAD_TCP",NAME,filePath.getName(),this.getClientIn().getText(),filePath);
			this.getChatBox().append("File Uploaded Successfully At " + new Date() + "\n");
			this.getClientIn().setText("");
			this.getUserName().setText("Enter Message : ");
			return;
		}
		

		if (Ob == this.getClientIn()
				&& this.getUserName().getText().equals("Enter Name of Person you wish to send the file over UDP protocol") && CONNECTED) {

				
			
			write(6,"UPLOAD_UDP",""+(int)filePath.length(),filePath.getName(),this.getClientIn().getText());	
			this.getClientIn().setText("");
			this.getUserName().setText("Enter Message : ");
			return;
		}
		
		if (Ob == this.getClientIn()
				&& this.getUserName().getText().equals("accept and begin upload in TCP ?") && CONNECTED) { 
			
			if(this.getClientIn().getText().equals("y")) { 
				stime = System.currentTimeMillis();
				write(6,"ACCEPT_TCP",NAME,"Server",NAME);
			}
			else 
				if(this.getClientIn().getText().equals("n"))
					write(6,"REJECT_TCP",NAME,"Server",NAME);
				else {
					this.getChatBox().append("Invalid Input String please enter y or n !");
					this.getClientIn().setText("");
					return;
				}
			this.getClientIn().setText("");
			this.getUserName().setText("Enter Message : ");
			return;
		}
		
		if (Ob == this.getClientIn()
				&& this.getUserName().getText().equals("accept and begin upload in UDP ?") && CONNECTED) { 
			
			if(this.getClientIn().getText().equals("y"))
				write(6,"ACCEPT_UDP",NAME,"Server",NAME);
			else 
				if(this.getClientIn().getText().equals("n"))
					write(6,"REJECT_UDP",NAME,"Server",NAME);
				else {
					this.getChatBox().append("Invalid Input String please enter y or n !");
					this.getClientIn().setText("");
					return;
				}
			this.getClientIn().setText("");
			this.getUserName().setText("Enter Message : ");
			return;
		}
			
		if (Ob == this.getClientIn()
				&& this.getUserName().getText().equals("Enter Name Here : ") && CONNECTED) {
			NAME = this.getClientIn().getText();
			this.getUserName().setText("Enter Message : ");
			write(0,"CONNECT",NAME,"Server",NAME);
			this.getClientIn().setText("");
			return;
		}
		
		
		if (Ob == this.getClientIn()
				&& this.getUserName().getText().equals("UserName : ") && !CONNECTED) {
			//obtains the user name and sets up textfield for data entry
			NAME = this.getClientIn().getText();
			this.getUserName().setText("Enter Message : ");
			
			makeConnection();
			if(CONNECTED)
				write(0,"CONNECT",NAME,"Server",NAME);	
			this.getClientIn().setText("");
			return;
		}
		if (Ob == this.getClientIn() && this.getUserName().getText().equals("Enter Chat Room You wish to join ! :")) { 
		write(2,"JOIN_CHAT_ROOM",NAME,"Server",this.getClientIn().getText());
		this.getClientIn().setText("");
		this.getUserName().setText("Enter Message : ");
		return;
		}

		if (Ob == this.getClientIn() && CONNECTED) {
			write(1,this.getClientIn().getText(),NAME,"Server","");
			this.getClientIn().setText("");
			return;
		}
		
		if(Ob == this.getMntmExit()) 
			this.close();
		
	}

	public int getPORT_NO() {
		return PORT_NO;
	}

	public void setPORT_NO(int pORT_NO) {
		PORT_NO = pORT_NO;
	}

	public String getSERVER_IP() {
		return SERVER_IP;
	}

	public void setSERVER_IP(String sERVER_IP) {
		SERVER_IP = sERVER_IP;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		Message m;
		while(true) {
		try {
			m = read();
			System.out.println(m.getSrc() + "  " + m.getDst());

			if(m.getTYPE() == 0) {
				getChatBox().append(m.getSrc() + " : " + m.getMSG() + "\n" );
				this.getUserName().setText("UserName : ");
				
			}
			
			if(m.getTYPE()==1) { 
				getChatBox().append(m.getSrc() + " : " + m.getMSG() + "\n" );
			
				}
			
			if(m.getTYPE()==2) {
				
				if(m.getMSG().equals("")) {
					etime = System.currentTimeMillis();
					double x = (etime - stime)/1000.0000000000000;
					this.getChatBox().append(x + " seconds taken to send the file estimate includes message sent from server to inform of file arrival \n And in case Of UDP time to create udp thread \n  And repetitive messages to inform server and client that it is okay to start sending \n");
				}
				
				if(m.getMSG().equals("CHAT_ROOM")){
					Room r = new Room(this,m.getInfo());
					this.getTabbedPane().addTab(r.getNAME()+"", r);
					this.getTABS().add(r);
				}
				
				if(m.getMSG().equals("CHAT_ROOM_P")){
					Room r = new Room(this,m.getInfo());
					r.getChatBox().setText("This is a Private Chat Room !");
					this.getTabbedPane().addTab(r.getNAME()+"", r);
					this.getTABS().add(r);
				}
				
				
				if(m.getMSG().equals("JOIN_ROOM")){
					Room r = new Room(this,m.getInfo());
					this.getTabbedPane().addTab(r.getNAME()+"", r);
					this.getTABS().add(r);
				}
				
				if(m.getMSG().equals("CLIENT_LIST"))
					getChatBox().append(m.getSrc() + " : " + m.getInfo() + "\n" );
				
				if(m.getMSG().equals("CHAT_ROOM_LIST"))
					getChatBox().append(m.getSrc() + " : " + m.getInfo() + "\n" );
				
				if(m.getMSG().equals("UPLOAD_TCP")){
					fileName = m.getInfo();
					getChatBox().append(m.getSrc() + " has sent you the file " + m.getInfo() + "\n" );
					this.getUserName().setText("accept and begin upload in TCP ?");
				}
				
				if(m.getMSG().equals("UPLOAD_UDP")) {
					
					fileName = m.getInfo();
					getChatBox().append(m.getSrc() + " has sent you the file " + m.getInfo() + "\n" );
					this.getUserName().setText("accept and begin upload in UDP ?");
				}
					
			}
			
			
			if(m.getTYPE() == 3) 
				search(m.getDst()).getChatBox().append(m.getSrc() +" : "+ m.getMSG() + "\n"); 
			if(m.getTYPE()==4) {
				if(m.getMSG().equals("CLOSE")){
					this.getTabbedPane().remove(search(m.getDst()));
					this.getTABS().remove(search(m.getDst()));
				}
				
				if(m.getMSG().equals("INVITE")){
					Room r = new Room(this,m.getInfo());
					this.getTabbedPane().addTab(r.getNAME()+"", r);
					this.getTABS().add(r);
				}
				
				
				if(m.getMSG().equals("MEMBER_LIST")||m.getMSG().equals("CLIENT_LIST")){
					search(m.getDst()).getChatBox().append(m.getSrc() +" : "+ m.getInfo() + "\n"); 
				}
				
				if(m.getMSG().equals("KICK_OFF")) {
					getChatBox().append(m.getSrc() + " : " + m.getInfo() + "\n" );
				}
				
				if(m.getMSG().equals("MUTE")) {
					Room r = search(m.getInfo());
					if(r.isMute()) {
					r.setMute(false);
					r.getChatBox().append("You just got unmuted from this chatroom by the admin \n");
					}
					else
					{
						r.setMute(true);
						r.getChatBox().append("You just got muted from this chatroom by the admin \n");
					}
				}
				
				
			}
			
			if(m.getTYPE()==5) {
				if(m.getMSG().equals("CONNECT")) {
					getChatBox().append(m.getSrc() + " : " + m.getInfo() + "\n" );
					this.getUserName().setText("Enter Name Here : ");
					
				}
				if(m.getMSG().equals("JOIN_ROOM"))
					getChatBox().append(m.getSrc() + " : " + m.getInfo() + "\n" );
				if(m.getMSG().equals("INVITE"))
					search(m.getDst()).getChatBox().append(m.getSrc() + " : " + m.getInfo() + "\n" );
			
				if(m.getMSG().equals("KICK_OFF"))	
					search(m.getDst()).getChatBox().append(m.getSrc() + " : " + m.getInfo() + "\n" );
				if(m.getMSG().equals("UPLOAD"))
					getChatBox().append(m.getSrc() + " : " + m.getInfo() + "\n" );
				if(m.getMSG().equals("MUTE"))
					search(m.getDst()).getChatBox().append(m.getSrc() + " : " + m.getInfo() + "\n" );
			}
			
			if(m.getTYPE() == 6) {
				if(m.getMSG().isEmpty()) {
					
					try {
						
						D_SOCKET = new DatagramSocket();
						FileInputStream fin = new FileInputStream(filePath);
					    byte fileContent[] = new byte[(int)filePath.length()];
					    InetAddress r = InetAddress.getByName("127.0.0.1");
					    fin.read(fileContent);
					    stime = System.currentTimeMillis();
					    D_SOCKET.send(new DatagramPacket(fileContent,fileContent.length,r,1254));
					    D_SOCKET.close();
					    fin.close();
					    this.getChatBox().append("File Uploaded Successfully At " + new Date() + "\n");
						
					} catch (SocketException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					catch(FileNotFoundException f1) {
						
						System.out.println(f1.getMessage());
					}
					catch(IOException i1) {
						System.out.println(i1.getMessage());
					}
					
				}
				if(m.getMSG().equals("FILE_TCP")) {
				etime = System.currentTimeMillis();
				double z = (etime - stime)/1000.0000000000000;
				this.getChatBox().append(z + " seconds taken to download file from server estimate includes messages sent back and forth to set up transfer");
				JFileChooser chooser = new JFileChooser();
				chooser.showOpenDialog(null);
				if(chooser.getSelectedFile()==null)
					return;
				
				/*try{ 
					   File f = (File)m.getOMSG();
					   FileInputStream fin = new FileInputStream(f);
				     
				       byte fileContent[] = new byte[(int)f.length()];
				       
				       fin.read(fileContent);
				       String strFileContent = new String(fileContent);
				       System.out.println("File content At Recieveing Client : ");
				       System.out.println(strFileContent);
				     
				    }
				    catch(FileNotFoundException e)
				    {
				      System.out.println("File not found" + e);
				    }
				    catch(IOException ioe)
				    {
				      System.out.println("Exception while reading the file " + ioe);
				    }*/ // Display File Content
				String b []  = chooser.getSelectedFile().getAbsolutePath().split("/");
				String target = "";
				for(int i = 0; i < b.length-1; i++)
					target+=b[i]+"//";
				
				target += fileName;
				System.out.println(target);
				File x = new File(target);
				copyFile((File)m.getOMSG(),x);

				}
				
			if(m.getMSG().equals("FILE_UDP")) {
				stime = System.currentTimeMillis();
				new UDPThread(new DatagramSocket(1254),Integer.parseInt(m.getInfo()),fileName,this.getChatBox(),(int)stime).start();
				write(6,"","","","");
			
				}
			}
		

			
			
		}
		catch(Exception e) {                 //General catch to ensure thread termination as close terminates all client resources except this thread
			
			return;
			
			}
		}
		
		}
	
	private static void copyFile(File sourceFile, File destFile) throws IOException { //Using NIO utilities through file channels
	    
		

	    FileChannel source = null;
	    FileChannel destination = null;

	    try {
	        source = new FileInputStream(sourceFile).getChannel();
	        destination = new FileOutputStream(destFile).getChannel();
	        destination.transferFrom(source, 0, source.size());
	    }
	    finally {
	        if(source != null) {                 //closing the channels and inout streams
	            source.close();
	        }
	        if(destination != null) {
	            destination.close();
	        }
	    }
	}
 
	
	public Room search(String n)  {
		
		for(Room current : this.getTABS()) 
			if(current.getNAME().equals(n))
				return current;
			
			return null;
		
	}
	
	public void removeTab() {
		
	}
	
	
	
	
		
	

}
