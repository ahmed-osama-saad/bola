package chat.guc.edu.engine;

import java.io.Serializable;

 public class Message implements Serializable{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/*
	  * TYPE = 0 = Name Exchange
	  * TYPE = 1 = Lobby Message
	  * TYPE = 2 = Special Request from Lobby members
	  * TYPE = 3 = ChatRoom messages
	  * TYPE = 4 = ChatRoom Special Request Messages
	  * TYPE = 6 = File
	  * TYPE = 5 = Error Messages 
	  * MSG : Contains Keywords regarding type of request in case of 0,2,4 and 5
	  * or contains the chat message itself in case of 1,3
	  * info : contains special information eg. client lists or member lists or "" if no info is needed
	  * src,dst : Server : Here src is Server/(ThreadName) and dst is ClientName
	  * 		  Client : Here src is ClientName and dst is Server
	  * 		  Client/Room: Here src is ClientName and dst is Room Name
	  * Certain differnces in src dst naming scheme are existent to accomodate for special cases.
	  */
	 int TYPE;
	 String MSG;
	 String src;
	 String dst;
	 String info;
	 Object OMSG;
	 
	 public Message(int t, String msg, String src, String dst, String i) { 
		 
		 TYPE = t;
		 MSG = msg;
		 info = i;
		 this.src = src;
		 this.dst = dst;
				 
	 }
	 
	 
	 public Message(int t, String msg, String src, String dst,String i, Object omsg) { 
		 
		 TYPE = t;
		 MSG = msg;
		 info = i;
		 OMSG = omsg;
		 this.src = src;
		 this.dst = dst;
				 
	 }
	 
	 
	 
	 
	 

	public int getTYPE() {
		return TYPE;
	}

	public void setTYPE(int tYPE) {
		TYPE = tYPE;
	}

	public String getMSG() {
		return MSG;
	}

	public void setMSG(String mSG) {
		MSG = mSG;
	}



	public String getSrc() {
		return src;
	}



	public void setSrc(String src) {
		this.src = src;
	}



	public String getDst() {
		return dst;
	}



	public void setDst(String dst) {
		this.dst = dst;
	}


	public String getInfo() {
		return info;
	}


	public void setInfo(String info) {
		this.info = info;
	}


	public Object getOMSG() {
		return OMSG;
	}


	public void setOMSG(Object oMSG) {
		OMSG = oMSG;
	}

}
