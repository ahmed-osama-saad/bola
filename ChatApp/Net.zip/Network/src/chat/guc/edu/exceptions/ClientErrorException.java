package chat.guc.edu.exceptions;

import java.net.UnknownHostException;

public class ClientErrorException extends UnknownHostException{
	
	public ClientErrorException() {
		super();
		
	}
	
	public ClientErrorException(String msg) {
		super(msg);
		
	}
	

}
